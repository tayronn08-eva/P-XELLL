package com.pikselcizim.app

/** Resmi n x n kareye indirir, döndürür, oyundaki renklere eşler. */
object Planner {

    class Group(val cand: Cols.C, val cells: IntArray)

    class Plan(
        val n: Int,
        val groups: List<Group>,
        val preview: IntArray,
        val total: Int
    )

    /** Dönen dizi: ARGB, 0 = saydam. */
    fun resample(px: IntArray, sw: Int, sh: Int, n: Int, skipWhite: Boolean): IntArray {
        val tw: Int
        val th: Int
        if (sw >= sh) {
            tw = n
            th = maxOf(1, Math.round(n.toFloat() * sh / sw))
        } else {
            th = n
            tw = maxOf(1, Math.round(n.toFloat() * sw / sh))
        }
        val ox = (n - tw) / 2
        val oy = (n - th) / 2
        val out = IntArray(n * n)
        for (ty in 0 until th) {
            val y0 = (ty.toLong() * sh / th).toInt()
            val y1 = minOf(sh, maxOf(y0 + 1, (((ty + 1).toLong() * sh + th - 1) / th).toInt()))
            for (tx in 0 until tw) {
                val x0 = (tx.toLong() * sw / tw).toInt()
                val x1 = minOf(sw, maxOf(x0 + 1, (((tx + 1).toLong() * sw + tw - 1) / tw).toInt()))
                var sa = 0L
                var sr = 0L
                var sg = 0L
                var sb = 0L
                var cnt = 0
                for (y in y0 until y1) {
                    for (x in x0 until x1) {
                        val p = px[y * sw + x]
                        val a = (p ushr 24) and 255
                        sa += a
                        sr += ((p shr 16) and 255) * a
                        sg += ((p shr 8) and 255) * a
                        sb += (p and 255) * a
                        cnt++
                    }
                }
                if (cnt == 0 || sa == 0L || sa / cnt < 128) continue
                val r = (sr / sa).toInt()
                val g = (sg / sa).toInt()
                val b = (sb / sa).toInt()
                if (skipWhite && r >= 245 && g >= 245 && b >= 245) continue
                out[(oy + ty) * n + (ox + tx)] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        return out
    }

    /** mode: 0 orijinal, 1 sola 90, 2 sağa 90, 3 180 */
    fun rotate(g: IntArray, n: Int, mode: Int): IntArray {
        if (mode == 0) return g
        val o = IntArray(n * n)
        for (r in 0 until n) {
            for (c in 0 until n) {
                val v = g[r * n + c]
                when (mode) {
                    1 -> o[(n - 1 - c) * n + r] = v
                    2 -> o[c * n + (n - 1 - r)] = v
                    else -> o[(n - 1 - r) * n + (n - 1 - c)] = v
                }
            }
        }
        return o
    }

    private fun dist(r1: Int, g1: Int, b1: Int, r2: Int, g2: Int, b2: Int): Int {
        val rm = (r1 + r2) / 2
        val dr = r1 - r2
        val dg = g1 - g2
        val db = b1 - b2
        return (((512 + rm) * dr * dr) shr 8) + 4 * dg * dg + (((767 - rm) * db * db) shr 8)
    }

    fun build(g: IntArray, n: Int, full: Boolean): Plan {
        val cands = Cols.all.filter { full || it.kind == 0 }
        val prev = IntArray(n * n)
        val lists = HashMap<Int, ArrayList<Int>>()
        var total = 0
        for (i in g.indices) {
            val p = g[i]
            if (p == 0) continue
            val r = (p shr 16) and 255
            val gg = (p shr 8) and 255
            val b = p and 255
            var best = 0
            var bd = Int.MAX_VALUE
            for (k in cands.indices) {
                val c = cands[k].rgb
                val d = dist(r, gg, b, (c shr 16) and 255, (c shr 8) and 255, c and 255)
                if (d < bd) {
                    bd = d
                    best = k
                }
            }
            prev[i] = cands[best].rgb
            lists.getOrPut(best) { ArrayList() }.add(i)
            total++
        }
        val groups = lists.keys.sorted().map { Group(cands[it], lists[it]!!.toIntArray()) }
        return Plan(n, groups, prev, total)
    }
}

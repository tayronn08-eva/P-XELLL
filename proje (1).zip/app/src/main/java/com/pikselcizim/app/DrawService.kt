package com.pikselcizim.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class DrawService : AccessibilityService() {

    companion object {
        @Volatile var instance: DrawService? = null
        @Volatile var pendingBitmap: Bitmap? = null
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var icon: TextView
    private lateinit var iconLp: WindowManager.LayoutParams
    private var panel: View? = null
    private lateinit var panelLp: WindowManager.LayoutParams
    private var panelShown = false
    private lateinit var info: TextView
    private lateinit var preview: ImageView

    private var srcPx: IntArray? = null
    private var srcW = 0
    private var srcH = 0
    private var size = 16
    private var dir = 0
    private var full = false
    private var skipWhite = false
    private var plan: Planner.Plan? = null

    @Volatile private var running = false

    private val flags =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    // ---------------------------------------------------------------- yaşam döngüsü

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildIcon()
        buildPanel()
        val pb = pendingBitmap
        if (pb != null) {
            pendingBitmap = null
            setImage(pb)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        try {
            hidePanel()
            wm.removeView(icon)
        } catch (e: Exception) {
        }
        instance = null
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- yardımcılar

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        handler.post { Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show() }
    }

    private fun rounded(color: Int, r: Int = 8): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    private fun styleBtn(b: Button, selected: Boolean) {
        b.background = rounded(if (selected) 0xFF2E7D32.toInt() else 0xFF455A64.toInt())
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        b.textSize = 13f
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun margins(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        return lp
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        tv.minWidth = dp(48)
        return tv
    }

    private fun choiceRow(
        title: String,
        labels: List<String>,
        initial: Int,
        onPick: (Int) -> Unit
    ): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(label(title))
        val bs = ArrayList<Button>()
        for (i in labels.indices) {
            val b = Button(this)
            b.text = labels[i]
            bs.add(b)
            b.setOnClickListener {
                for (j in bs.indices) styleBtn(bs[j], j == i)
                onPick(i)
            }
            row.addView(b, margins())
        }
        for (j in bs.indices) styleBtn(bs[j], j == initial)
        return row
    }

    // ---------------------------------------------------------------- simge

    private fun buildIcon() {
        icon = TextView(this)
        icon.text = "P"
        icon.setTextColor(Color.WHITE)
        icon.textSize = 18f
        icon.typeface = Typeface.DEFAULT_BOLD
        icon.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xCC3366CC.toInt())
        bg.setStroke(dp(2), Color.WHITE)
        icon.background = bg

        val sz = dp(52)
        iconLp = WindowManager.LayoutParams(
            sz, sz,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        iconLp.gravity = Gravity.TOP or Gravity.START
        iconLp.x = dp(8)
        iconLp.y = dp(120)

        icon.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX
                        sy = e.rawY
                        ox = iconLp.x
                        oy = iconLp.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx
                        val dy = e.rawY - sy
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved && !running) {
                            iconLp.x = ox + dx.toInt()
                            iconLp.y = oy + dy.toInt()
                            wm.updateViewLayout(icon, iconLp)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) onIconClick()
                    }
                }
                return true
            }
        })
        wm.addView(icon, iconLp)
    }

    private fun onIconClick() {
        if (running) {
            running = false
            toast("Durduruluyor...")
        } else if (panelShown) {
            hidePanel()
        } else {
            showPanel()
        }
    }

    // ---------------------------------------------------------------- panel

    private fun buildPanel() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.background = rounded(0xEE1E2A3A.toInt(), 12)
        root.setPadding(dp(10), dp(8), dp(10), dp(8))

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL

        // başlık satırı
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Piksel Çizim"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        head.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = Button(this)
        close.text = "✕"
        styleBtn(close, false)
        close.setOnClickListener { hidePanel() }
        head.addView(close, margins())
        left.addView(head)

        val pick = Button(this)
        pick.text = "Resim yükle (galeri)"
        styleBtn(pick, false)
        pick.setOnClickListener {
            val i = Intent(this, PickActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        left.addView(pick, margins())

        info = TextView(this)
        info.setTextColor(0xFFB0BEC5.toInt())
        info.textSize = 12f
        info.text = "Resim seçilmedi"
        left.addView(info)

        left.addView(choiceRow("Boyut", listOf("16x16", "32x32"), 0) {
            size = if (it == 0) 16 else 32
            rebuild()
        })
        left.addView(choiceRow("Yön", listOf("Orijinal", "90° sol", "90° sağ", "180°"), 0) {
            dir = it
            rebuild()
        })
        left.addView(choiceRow("Renk", listOf("Hazır palet", "Tüm renkler"), 0) {
            full = it == 1
            rebuild()
        })
        left.addView(choiceRow("Beyaz", listOf("Çiz", "Atla"), 0) {
            skipWhite = it == 1
            rebuild()
        })

        val start = Button(this)
        start.text = "Başla"
        styleBtn(start, true)
        start.textSize = 16f
        start.setOnClickListener { startDraw() }
        left.addView(start, margins())

        root.addView(left)

        preview = ImageView(this)
        preview.setBackgroundColor(0xFF37474F.toInt())
        preview.scaleType = ImageView.ScaleType.FIT_CENTER
        val plp = LinearLayout.LayoutParams(dp(150), dp(150))
        plp.setMargins(dp(10), dp(4), 0, 0)
        root.addView(preview, plp)

        panel = root
        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        panelLp.gravity = Gravity.TOP or Gravity.START
        panelLp.x = dp(70)
        panelLp.y = dp(6)
    }

    private fun showPanel() {
        val p = panel ?: return
        if (panelShown) return
        wm.addView(p, panelLp)
        panelShown = true
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (!panelShown) return
        try {
            wm.removeView(p)
        } catch (e: Exception) {
        }
        panelShown = false
    }

    // ---------------------------------------------------------------- resim

    fun setImage(b: Bitmap) {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        srcPx = px
        srcW = w
        srcH = h
        rebuild()
        showPanel()
    }

    private fun rebuild() {
        val px = srcPx
        if (px == null) {
            plan = null
            info.text = "Resim seçilmedi"
            return
        }
        val n = size
        var g = Planner.resample(px, srcW, srcH, n, skipWhite)
        g = Planner.rotate(g, n, dir)
        val p = Planner.build(g, n, full)
        plan = p

        val small = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        small.setPixels(p.preview, 0, n, 0, 0, n, n)
        val s = 256 / n
        preview.setImageBitmap(Bitmap.createScaledBitmap(small, n * s, n * s, false))
        info.text = "Resim ${srcW}x${srcH}  •  kare: ${p.total}  •  renk: ${p.groups.size}"
    }

    // ---------------------------------------------------------------- çizim

    private fun startDraw() {
        val p = plan
        if (p == null || p.total == 0) {
            toast("Önce resim yükle")
            return
        }
        hidePanel()
        val sz = screenSize()
        Geo.setScreen(sz.first, sz.second)
        iconLp.x = dp(4)
        iconLp.y = (minOf(sz.first, sz.second) * 0.55f).toInt()
        wm.updateViewLayout(icon, iconLp)
        icon.text = "■"
        running = true
        toast("1,5 saniye sonra başlıyor. Durdurmak için ■ simgesine dokun.")
        Thread { drawAll(p) }.start()
    }

    private fun drawAll(p: Planner.Plan) {
        var finished = false
        try {
            sleepMs(1500)
            var done = 0
            outer@ for (g in p.groups) {
                if (!running) break
                if (!selectColor(g.cand)) {
                    fail("Dokunma gönderilemedi (renk seçimi)")
                    break
                }
                val pts = ArrayList<PointF>()
                for (cell in g.cells) pts.add(Geo.cell(cell / p.n, cell % p.n, p.n))
                var i = 0
                while (i < pts.size) {
                    if (!running) break@outer
                    val end = minOf(i + 10, pts.size)
                    if (!tapBatch(pts.subList(i, end))) {
                        fail("Dokunma gönderilemedi")
                        break@outer
                    }
                    done += end - i
                    i = end
                    val pct = done * 100 / p.total
                    handler.post { icon.text = "%$pct" }
                    sleepMs(40)
                }
            }
            finished = running
        } finally {
            val ok = finished
            handler.post {
                running = false
                icon.text = "P"
                toast(if (ok) "Bitti ✔" else "Durdu")
            }
        }
    }

    private fun fail(msg: String) {
        running = false
        toast(msg)
    }

    private fun selectColor(c: Cols.C): Boolean {
        val pt = Geo.pointOf(c)
        if (c.kind == 0) {
            if (!tapBatch(listOf(pt))) return false
            sleepMs(200)
            return true
        }
        if (!tapBatch(listOf(Geo.rainbow()))) return false
        sleepMs(800)
        if (!tapBatch(listOf(pt))) return false
        sleepMs(300)
        if (!tapBatch(listOf(Geo.pickerOk()))) return false
        sleepMs(700)
        return true
    }

    /** En fazla 10 dokunuşu tek hareket olarak gönderir. */
    private fun tapBatch(pts: List<PointF>): Boolean {
        for (attempt in 0 until 3) {
            if (!running) return true
            val b = GestureDescription.Builder()
            for (i in pts.indices) {
                val path = Path()
                path.moveTo(pts[i].x, pts[i].y)
                b.addStroke(GestureDescription.StrokeDescription(path, (i * 70).toLong(), 40L))
            }
            val latch = CountDownLatch(1)
            var okRes = false
            val cb = object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    okRes = true
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            }
            val accepted = dispatchGesture(b.build(), cb, null)
            if (accepted) {
                latch.await(8, TimeUnit.SECONDS)
                if (okRes) return true
            }
            sleepMs(200)
        }
        return false
    }

    private fun sleepMs(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }
}

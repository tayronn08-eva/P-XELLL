package com.pikselcizim.app

/** Oyundaki renk seçeneklerinin listesi (ekran görüntülerinden ölçüldü). */
object Cols {
    /** kind 0 = ana palet (a=sütun, b=satır), 1 = gri kutucuk (a=sıra), 2 = gökkuşağı ızgarası (a=sütun, b=satır) */
    class C(val rgb: Int, val kind: Int, val a: Int, val b: Int)

    private val PAL = arrayOf(
        arrayOf("", "000000", "ffffff", "d90a1c", "fea348", "ffdf00", "1eff00"),
        arrayOf("01e87e", "62a0e9", "c060cb", "ff69b3", "63452b", "e01b24", "ff7900"),
        arrayOf("f6d32d", "33d17a", "3584e3", "9240ac", "976a43", "f76152", "ffbd6f"),
        arrayOf("f9f16c", "8ff0a3", "99c1f2", "dc8ade", "ffc0cb", "cdab8f", ""),
    )
    private val GRAYS = arrayOf("333333", "666666", "999999", "cccccc")
    private val GRID = arrayOf(
        "ffefef,fff2ef,fef5ee,fff8ee,fffbef,fffeef,fdffef,fbfff0,f7ffef,f4ffef,f1ffee,effff0,effff4,effff5,effffa,effffc,efffff,eefcff,f0f9ff,eff6ff,eff3ff,eef0ff,f1eeff,f3effe,f7eeff,faefff,fdefff,ffeefe,ffeffa,ffeff9,ffeef4,ffeff2",
        "ffdfe0,fee5e0,ffebe0,fef1e0,fff7e0,fefddf,fbfedf,f5fedf,f0ffe0,eaffe0,e4ffe0,deffe0,dfffe7,deffec,dffff2,dffff9,dffffe,e0f9fe,dff3fe,e0edfe,dfe7fe,e0e1ff,e3e0ff,e9e0ff,eedffe,f4dffe,fadffe,ffdffe,ffdff7,ffdff2,ffdfec,ffdee5",
        "ffcfcf,ffd9d0,fee1cf,ffeacf,fdf3cf,fffccf,f9ffcf,efffd0,e7ffcf,deffd0,d5ffcf,d0ffd3,d0ffdb,cfffe5,cfffed,d0fff7,cfffff,cff5fe,d0edff,cfe4ff,cfdcff,cfd2ff,d5cfff,dfcffe,e7cfff,f0cffe,f9cfff,fecffb,fecff3,ffcfe9,ffcee1,fecfd7",
        "ffbfbf,ffcbbe,ffd7be,ffe3be,ffefbe,fffbbe,f6ffbe,ebffbf,dfffbe,d3ffbf,c7ffbe,bfffc3,bffecf,bfffdc,bfffe7,bffef3,bfffff,bff3ff,bfe7ff,bfdbff,bfcfff,bfc3ff,c8bfff,d3beff,dfbfff,ebbeff,f7beff,ffbffb,ffc0ef,ffbfe2,ffbfd7,ffc0cb",
        "ffafb0,ffbeb0,ffceb0,fedcaf,ffebb0,fffab0,f6ffb0,e6ffae,d8ffb0,c8ffae,baffaf,afffb4,afffc2,b0ffd2,afffe0,aefff0,affffe,aef0fe,afe0fe,b0d2ff,afc3fe,aeb4fe,b8affe,c8afff,d6affe,e6afff,f4afff,ffaefa,ffafec,feafdc,ffaece,ffafbe",
        "ff9fa0,feb19f,ffc39f,fed59f,ffe79f,fffa9f,f3fe9e,e1ff9f,d0ff9f,bdff9e,abff9f,9fffa5,9fffb7,9effc9,9fffda,9effec,9ffffe,a0edff,9fdbff,9fcaff,9fb7ff,9fa4ff,aba0ff,bd9fff,ce9fff,e19fff,f39fff,ff9ff9,ff9fe7,ff9fd5,ff9fc4,ff9fb2",
        "ff8f8e,ffa48f,feb98f,ffcd8e,ffe38f,fff88e,f1ff8e,ddff8f,c6ff8e,b2ff8f,9dff90,90ff96,8fffab,8effbf,8fffd5,8fffe9,8fffff,8feaff,90d5ff,8fc1ff,8fabff,8f96ff,9d8fff,b18fff,c88fff,dc8fff,f18ffe,fe8ff8,ff8fe3,ff8fcf,ff8eb9,ff8fa5",
        "fe8081,ff9680,ffaf80,ffc780,ffdf80,fff780,efff80,d7ff80,beff7f,a6ff7f,8fff7f,7fff86,7fff9e,80ffb6,80ffcf,7fffe8,7ffffe,81e7fe,81cfff,81b7ff,819fff,8187ff,8f80ff,a780ff,be80ff,d680ff,ef80ff,ff80f7,ff80df,ff80c7,ff7faf,ff8097",
        "ff7170,ff8a70,ffa570,ffc070,ffdb70,fef66f,edfe71,d2ff70,b7fe70,9cff70,81ff70,6fff79,70ff93,70ffaf,70ffc9,70fee4,6fffff,70e3fe,70caff,70afff,7193ff,7179ff,816fff,9b70fe,b870ff,d271ff,ee70ff,ff70f6,ff70da,ff70c0,ff70a5,ff718b",
        "ff6160,ff7e5f,ff9b60,ffb961,ffd660,fff560,ebff60,cdff60,afff60,91ff60,73ff60,60fe69,60ff88,60ffa5,60ffc4,60ffe1,5fffff,60e1ff,60c2ff,60a5ff,6087ff,606aff,7460ff,9260ff,b060ff,ce60ff,ec60ff,ff61f6,ff60d7,ff60ba,ff5f9b,ff607e",
        "fe504f,ff7151,fe9150,feb250,ffd350,fff450,e8ff4f,c9ff51,a7ff50,87ff50,66ff4f,50ff5c,50ff7c,50fe9c,50ffbe,50ffde,50ffff,4fdefe,50bdfe,519dff,507cff,4f5bff,6750ff,8650fe,a750ff,c850ff,e950ff,ff50f3,ff50d3,ff4fb1,ff5091,ff5071",
        "fe4040,fe6440,ff8740,ffab40,ffcf3f,fff33f,e8fe41,c3fe40,a0ff41,7cff41,58ff40,3ffe4c,40ff71,40ff93,40ffb7,40ffdb,3fffff,41dbff,41b7ff,4092fe,4070ff,404cff,5741fe,7c41ff,9f40fe,c340fe,e740ff,ff41f3,ff40ce,ff40aa,ff4086,ff3f64",
        "fe3030,ff5730,ff7e30,ffa431,ffcb31,fff231,e6ff31,beff2f,97ff30,71ff2f,49ff30,30ff3d,2fff63,30ff89,30ffb1,31ffd8,2fffff,30d8ff,2fb1ff,2f8aff,2f64fe,303dfe,4930fe,7130ff,972ffe,be30ff,e630ff,ff30f2,ff30cc,ff30a4,ff307e,fe3057",
        "ff2120,ff4a1f,ff7421,ff9d20,ffc720,fff11f,e3ff1f,b9ff20,8fff1f,67ff20,3cff1f,1fff2d,20ff57,20ff82,20ffac,21ffd6,1fffff,20d5ff,20abfe,1f81fe,1f58ff,202eff,3c20ff,661fff,8f21ff,b820ff,e320ff,ff20f2,ff20c8,ff209d,ff2073,fe2049",
        "fe1010,ff3d11,ff6a10,fe960f,ffc212,fff00f,e1ff11,b4ff0f,87ff11,59ff10,2eff10,10ff1e,10ff4c,0fff78,10ffa4,0fffd2,10ffff,0fd2fe,10a5ff,1179ff,0f4cff,101fff,2e10fe,5b10ff,8710fe,b40fff,e110ff,ff10f1,ff10c1,ff1097,ff106d,ff103d",
        "fe0000,fe3000,ff6100,ff8e01,ffbe00,fdf001,dffe00,afff00,80ff00,50ff00,1fff00,01ff11,00ff41,00fe70,00ff9f,00ffcf,00ffff,01cfff,009eff,0071fe,0041ff,000ffe,2001ff,5000ff,7f00ff,af00ff,e000ff,fe00ee,ff00be,ff018f,ff0060,ff0030",
    )

    private fun hex(s: String): Int = (0xFF shl 24) or Integer.parseInt(s, 16)

    val all: List<C> by lazy {
        val l = ArrayList<C>()
        for (r in PAL.indices) for (c in PAL[r].indices) {
            if (PAL[r][c].isNotEmpty()) l.add(C(hex(PAL[r][c]), 0, c, r))
        }
        for (i in GRAYS.indices) l.add(C(hex(GRAYS[i]), 1, i, 0))
        for (r in GRID.indices) {
            val cells = GRID[r].split(",")
            for (c in cells.indices) l.add(C(hex(cells[c]), 2, c, r))
        }
        l
    }
}

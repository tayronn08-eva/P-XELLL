package com.pikselcizim.app

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast

@Suppress("DEPRECATION")
class PickActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "Resim seç"), 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode == RESULT_OK && uri != null) {
            try {
                val bounds = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var s = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / s > 1024) s *= 2
                val opt = BitmapFactory.Options()
                opt.inSampleSize = s
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt) }
                if (bmp == null) {
                    Toast.makeText(this, "Resim açılamadı", Toast.LENGTH_LONG).show()
                } else {
                    val svc = DrawService.instance
                    if (svc != null) {
                        svc.setImage(bmp)
                    } else {
                        DrawService.pendingBitmap = bmp
                        Toast.makeText(this, "Erişilebilirlik hizmeti kapalı. Önce onu aç.", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Hata: " + e.message, Toast.LENGTH_LONG).show()
            }
        }
        finish()
    }
}

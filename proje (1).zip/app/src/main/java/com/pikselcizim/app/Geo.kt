package com.pikselcizim.app

import android.graphics.PointF

/**
 * Oyun ekranının 1600x720 ekran görüntüsünde ölçülen koordinatları.
 * Ekran farklıysa yüksekliğe göre ölçeklenir, yatayda ortalanır.
 */
object Geo {
    private const val RW = 1600f
    private const val RH = 720f

    private var scale = 1f
    private var offX = 0f

    // Çizim alanı (kare)
    private const val CANVAS_L = 336f
    private const val CANVAS_T = 153f
    private const val CANVAS_S = 537f

    private val GRAY_X = floatArrayOf(838f, 886f, 939f, 990f)

    fun setScreen(w: Int, h: Int) {
        val ww = maxOf(w, h).toFloat()
        val hh = minOf(w, h).toFloat()
        scale = hh / RH
        offX = (ww - RW * scale) / 2f
    }

    private fun px(x: Float) = offX + x * scale
    private fun py(y: Float) = y * scale

    fun cell(row: Int, col: Int, n: Int): PointF =
        PointF(
            px(CANVAS_L + (col + 0.5f) * CANVAS_S / n),
            py(CANVAS_T + (row + 0.5f) * CANVAS_S / n)
        )

    fun rainbow(): PointF = PointF(px(918f), py(152f))

    fun pickerOk(): PointF = PointF(px(1008f), py(626f))

    fun pointOf(c: Cols.C): PointF = when (c.kind) {
        0 -> PointF(px(918f + 56f * c.a), py(152f + 56f * c.b))
        1 -> PointF(px(GRAY_X[c.a]), py(556f))
        else -> PointF(
            px(640f + (c.a + 0.5f) * 556f / 32f),
            py(228f + (c.b + 0.5f) * 276f / 16f)
        )
    }
}

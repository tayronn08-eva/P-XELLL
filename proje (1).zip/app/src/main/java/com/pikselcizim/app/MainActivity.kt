package com.pikselcizim.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "Piksel Çizim"
        title.textSize = 24f
        root.addView(title)

        val help = TextView(this)
        help.textSize = 15f
        help.text = "Kurulum:\n" +
            "1) Aşağıdaki düğmeyle Erişilebilirlik ayarlarını aç, \"Piksel Çizim\" hizmetini aç.\n" +
            "   (İzin gri ise: Uygulama bilgisi > ⋮ menüsü > Kısıtlı ayarlara izin ver.)\n" +
            "2) Hizmet açılınca ekranda sürüklenebilir \"P\" simgesi çıkar.\n" +
            "3) Oyunda Özel Eşya Yapma ekranını aç, P'ye dokun, resim seç, Başla."
        root.addView(help)

        status = TextView(this)
        status.textSize = 16f
        root.addView(status)

        root.addView(button("Erişilebilirlik ayarlarını aç") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("Uygulama bilgisini aç") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        })
        root.addView(button("Resim seç (yedek yol)") {
            startActivity(Intent(this, PickActivity::class.java))
        })

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onResume() {
        super.onResume()
        status.text = if (DrawService.instance != null)
            "\nDurum: Hizmet AÇIK ✔  (ekranda P simgesi olmalı)\n"
        else
            "\nDurum: Hizmet KAPALI\n"
    }
}
